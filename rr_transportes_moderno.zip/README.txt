
# RR Transportes - Landing Page

### Como editar imagens:

1. Abra o arquivo `index.html` com um editor de texto (VS Code ou Bloco de Notas).
2. Procure por esta linha:

   style="background-image: url('...')"

3. Troque o link da imagem por outro link direto de imagem (de preferência do Unsplash ou similar).

Exemplo:
https://images.unsplash.com/photo-xxx

Salve e abra `index.html` no navegador para ver a alteração.
